This project is a flexible and simple game engine that could be used to make 2D games.

It is currently still heavily under development, but it is still functional as a pip library.
